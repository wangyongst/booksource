public class For
{
    public static void shushu5 (){
        /**
	 *
	 * 定义一个整数型变量i，并初始化它的值为1；
         * 变量i的值不是101的时候，循环执行输出
         * 变量i自增更新
	 */
        for(int i = 1;i != 101;i++){  //
             System.out.println(i);  //输出变量i的值。
        }
    }
    
    public static void shuziqi(){
    /**
     * 定义一个整数型变量i，并初始化它的值为1；
     * 如果变量i的值小于等于50，则执行循环内容
     * 也就是如果变量i的值大于50时，则中止循环。。
     * 并在执行完循环内容后让变量i自增
     */
        for(int i = 1 ; i <= 50 ; i ++){
        /**
         * 判断i%10==7或者i%7==0j 是否为真。
         */
            if( i%7 ==0 || i%10 ==7){
                System.out.println("过");  //为真，则输出“过”这个字
            }else{
                System.out.println(i);  //为假，则输出i的值
            }
        }
    }  
    
}
