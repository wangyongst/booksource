public class Shi
{

    /**
     * 用*号绘制三角形图案
     *      
     */
    public static void sjx()
    {
        for(int i = 1 ; i < 5 ; i ++){
            for(int j = 1 ; j <= i ; j ++){                
                    System.out.print("*");
            }
            System.out.println();
        }
    }
    
    public static void zhuanyi()
    {
           System.out.println("小明说:\"老师告诉我说\'今天晚上没有作业\'\".");
    }
    
    public static void zhuanyi2()
    {
           System.out.println("这是转义后的\\");
    }
    
    /**
     * 格式对齐的九九乘法表
     *      
     */
    public static void chengfa() {
        for(int i = 1; i <= 9; i++) {
            for(int j = 1; j <= i; j++) {
                System.out.print(i+"*"+j+"="+i*j+"\t") ;
            }
            System.out.println();
        }
    }
    
    /**
     * 英文字母表
     *      
     */
    public static void zimu() {
        for(char i = 'a'; i <= 'z' ; i++) {
                 System.out.print(i) ;
        }
    }
    
    /**
     * 每行6个字母的英文字母表
     *      
     */
    public static void zimu2() {
        for(char i = 'a'; i <= 'z' ; i++) {
              System.out.print(i+"\t") ;
              if((i - 'a') % 6 == 5){
                  System.out.println();
              }
        }
     }
    
    /**
     * 每行6个字母的英文大写字母表
     *      
     */
    public static void zimu3() {
        for(char i = 'A'; i <= 'Z' ; i++) {
              System.out.print(i+"\t") ;
              if((i - 'A') % 6 == 5){
                  System.out.println();
              }
        }
    }
    
    
    /**
     * 每行6个字母的英文大小写字母表
     *      
     */
    public static void zimu4() {
        for(char i = 'A'; i <= 'z' ; i++) {
              System.out.print(i+"\t") ;
              if((i - 'A') % 6 == 5){
                  System.out.println();
              }
        }
    }
    
    public static void paixu() {
	/**
         * 定义并初始化字符型数组变量a
         * 并把T，e，S，t，o，N，m，e这8个字母存储在变量a中
         */
	char a[] = {'T','e','S','t','o','N','m','e'};
        /**
         * 冒泡排序的for循环实现方法
         * 变量i代表循环轮数
         * 用a[j]访问要比较的数据，用a[j+1]访问a[j]右边的数据
	 */
	for (int i = 0; i < 8; i++) {
	        /**
	         * j < 8 -1 - i代表要比较到哪一位数据为止
	         */
		for (int j = 0; j < 8-1-i; j++) {
			/**
			* 如果当前数据比右边位置的数据大，就交换两个数据的位置
			*/
			if (a[j] > a[j+1]) {
				char x = a[j+1];
				a[j+1] = a[j];
				a[j] = x;
			}
		}
	}
        /**
        * 用for循环的数组遍历语法，让电脑依次输出数组中的值
        */
	for(char n : a){
		System.out.print(n);
	}
   }
    
    
    /**
     * 让电脑判断输入的整数是不是质数
     *      
     */
    public static void zhishu(int a)
    {
        //定义一个整数型变量c，并初始化c的值为0。c用于记录能被整除的次数。
        int c = 0;
        /**
         * for循环定义整数型变量i，并初始化它的值为2；
         * for循环布尔表达式条件为i < a；
         * for循环变量更新为i++；
         */
        for(int i = 2 ; i < a ; i ++){
            if(a % i == 0){  //循环判断a% i== 0是否为真                
                c++;   //为真，则c++，代表能被整除的次数加一次
            }
        }
        
        if(c > 0){  //for循环结束后，判断c>0是否为真               
               System.out.println(a+"不是质数");   //为真，则a不是质数
        }else{
            System.out.println(a+"是质数");  //为假，则a是质数
        }
    }
    
    /**
     * 让电脑判断输入的整数是不是质数的优化方法
     *      
     */
    public static void zhishu2(int a)
    {
        /**
         * for循环定义整数型变量i，并初始化它的值为2；
         * for循环布尔表达式条件为i < a；
         * for循环变量更新为i++；
         */
        for(int i = 2 ; i < a ; i ++){
            if(a % i == 0){  //循环判断a% i== 0是否为真                
                System.out.println(a+"不是质数");    //为真，则a不是质数
                break; //循环提前结束
            }
            //循环没有提前结束，也就是当循环执行完i=a-1时的判断后，则a是质数            
            if(i == a - 1){ 
               System.out.println(a+"是质数"); 
            }
        }        
    }
}
