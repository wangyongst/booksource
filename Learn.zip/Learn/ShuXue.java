public class ShuXue{
    public static void plus(int a,int b)
    {
        System.out.println(a+b);
    }
    
    public static void print(int a,int b)
    {
        int c = 0;
        System.out.println(c);
        c = a+b;
        System.out.println(c);
    }
    
    public static void type()
    {
        byte a = 0;
        System.out.println(a);
        short b = 0;
        System.out.println(b);
        int c = 0;
        System.out.println(c);
        long d = 0l;
        System.out.println(d);
        float e = 0.0f;
        System.out.println(e);
        double f = 0.0d;
        System.out.println(f);
        char g = 'c';
        System.out.println(g);
        boolean h = true;  
        System.out.println(h);
    }
    
     public static void change()
    {
        int a = 2;
        int b= 3;
        int c = 0;
        c = a;
        a = b;
        b = c;
        System.out.println(a);
        System.out.println(b);
    }
    
    public static void equals(int a,int b,int c)
    {
        int d = a + b;
        boolean e = (d==c);
        System.out.println(e);
    }
    
    /**
     * 这个方法是接收两个整型参数a和b
     * 并计算a是否等于b的两倍
     */
    public static void method(int a,int b)
    {      
        boolean e = (a==2*b);  //布尔型变量e存储 a == 2*b表达式的判断结果
        System.out.println(e);  //将布尔型变量e的值输出
    }
}