import java.util.Scanner;  //声明引入Scanner工具类

public class Input2  //我们自己定义的程序类
{
   public static void input2()  //我们自己定义的程序方法
    {
        //开始使用Scanner工具类
        Scanner sc = new Scanner(System.in);   
        //使用while循环判断是否有新的输入
        while (sc.hasNext()) {
            //获取从键盘输入的数据
            String input = sc.next();            
            if(input.equals("你好"))  //如果键盘输入“你好”时，电脑对应的回话
            {
                System.out.println("你好");
            }else if(input.equals("再见"))  //如果键盘输入“再见”时，电脑对应的回话
            {
                System.out.println("再见");
                return;
            }else if(input.equals("你是谁"))  //如果键盘输入“你是谁”时，电脑对应的回话
            {
                System.out.println("我是电脑");
            }else if(input.equals("你几岁了")) //如果键盘输入“你几岁了”时，电脑对应的回话
            {
                System.out.println("我不知道");
            }
        }
    }
}
