public class While
{
    
    public static void plus (){
       int a = 5;
       a = a + 1;
       System.out.println(a);
    }
    
    public static void plus2 (){
       int a = 5;       
       a++;  //使用自增运算符使变量加1
       System.out.println(a);
    }
    
    public static void reduce (){
       int a = 5;       
       a--;  //使用自减运算符使变量减1
       System.out.println(a);
    }
    
    public static void shibian (){
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
       System.out.println("学习Java编程真有趣");
    }
    
    
    public static void wushu (){
        while(true){
             System.out.println("学习Java编程真有趣");
        }
    }
    
    public static void wushu2 (){
        int a = 1;
        int b = 0;
        while(a>b){
             System.out.println("学习Java编程真有趣");
        }
    }
    
    public static void wushu3 (){
        int a = 1;
        int b = 2;
        while(a>b){
             System.out.println("学习Java编程真有趣");
        }
    }
    
    public static void shushu (){
        int i = 1;  //定义一个整数型变量i，并初始化它的值为1；
        while(true){  //循环执行
             System.out.println(i);  //输出变量i的值。
             i++;  //让变量i自增
        }
    }
    
    public static void daoshu (){
        int i = 1000;  //定义一个整数型变量i，并初始化它的值为1000；
        while(true){  //循环执行
             System.out.println(i);  //输出变量i的值。
             i--;  //让变量i自减
        }
    }
    
    public static void shushu2 (){
        int i = 1;
        while(true){
             System.out.println(i);
             i++;
             break;
        }
    }
    
    public static void shushu3 (){
        int i = 1;  //定义一个整数型变量i，并初始化它的值为1；
        while(true){  //循环执行
             System.out.println(i);  //输出变量i的值。
             i++;  //让变量i自增
             if(i == 101){
                 break;  //如果变量i的值是101的时候，则中止循环。
             }
        }
    }
    
    public static void shushu4 (){
        int i = 1;  //定义一个整数型变量i，并初始化它的值为1；
        while(i != 101){  //变量i的值不是101的时候，循环执行输出和自增操作
             System.out.println(i);  //输出变量i的值。
             i++;  //让变量i自增
        }
    }
    
    public static void cunqian (){
        int i = 1;  //定义一个整数型变量i，并初始化它的值为1；
        int sum = 0;  //定义一个整数型变量sum，并初始化它的值为0，用来保存累加的值。
        while(i != 101){  //变量i的值不是101的时候，循环执行累加和自增
             sum = sum + i; //计算累加
             i++;  //让变量i自增
        }
         System.out.println(sum);  //循环结束后，输出变量sum的值。
    }
}
