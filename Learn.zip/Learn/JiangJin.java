import java.util.Scanner;
public class JiangJin
{
    public static void jiangJin() {
        Scanner sc = new Scanner(System.in);
        System.out.print("本年度利润额(万元)：");
        double all = 0.0d;
        while (sc.hasNext()) 
        {
            int a = sc.nextInt();
            while (a > 0)
            {
                if (a > 100) 
                {
                    all = all + (a - 100) * 0.01;
                    a = 100;
                }
                else if (a <= 100 && a > 60) 
                {
                    all = all + (a - 60) * 0.015;
                    a = 60;
                }
                else if (a <= 60 && a > 40)
                {
                    all = all + (a - 40) * 0.03;
                    a = 40;
                } 
                else if (a <= 40 && a > 20) 
                {
                    all = all + (a - 20) * 0.05;
                    a = 20;
                } 
                else if (a <= 20 && a > 10) 
                {
                    all = all + (a - 10) * 0.075;
                    a = 10;
                } 
                else if (a <= 10) 
                {
                    all = all + a * 0.1;
                    a = a - 10;
                }
            }
            System.out.print("本年度应得奖金提成为(万元)：" + all);
            return;
        }
    }
}
