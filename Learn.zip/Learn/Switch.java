public class Switch
{
        /**
	 *
	 * 输入一个数字ａ
	 */
	public static void ruguo(int a){
		if(a == 1){
			System.out.println("一");  //如果ａ== 1，则输出汉字“一”
		}else{  //其它
			if(a == 2){
				System.out.println("二");  //如果 ａ== 2，则输出汉字“二”
			}else{  //其它
				if(a == 3){
					System.out.println("三");  //如果 ａ== 3，则输出汉字“三”
				}else{  //其它
					System.out.println("其它");  //输出汉字“其它”
				}
			}
		}
	}
	
	/**
	 *
	 * 输入一个数字ａ
	 */
	public static void dang(int a){
		switch (a){		
			case 1 :   
				System.out.println("一");   // 当ａ为1时，输出汉字“一”
				break;		
			case 2:
				System.out.println("二");   // 当ａ为2时，输出汉字“二”
				break;		
			case 3:
				System.out.println("三");   // 当ａ为3时，输出汉字“三”
				break;			
			default:
				System.out.println("其它");  // 当ａ为其它值时，输出汉字“其它”
		}
	}
	
	
	/**
	 * 输入一个数字ａ
	 */
	public static void jijie(int a)
	{
		if(a >=1 && a<=3)
		{
			System.out.println("春季");  //如果 a>=1并且 a<=3  则输出汉字“春季”
		}
		else
		{
			if(a >=4 && a<=6)
			{
				System.out.println("夏季");  //如果 a>=4并且 a<=6  则输出汉字“夏季”
			}
			else
			{
				if(a>=7&& a<=9)
				{
					System.out.println("秋季");  //如果 a>=7并且 a<=9  则输出汉字“秋季”
				}
				else
				{
					if(a>=10&& a<=12){
						System.out.println("冬季");  //如果 a>=10并且 a<=12  则输出汉字“冬季”
					}
				}
			}
		}
	}
	
	
	/**
	 *
	 * 输入一个数字ａ
	 */
	public static void jijie2(int a){
		switch (a){
			case 1 :
				System.out.println("春季");  //当a为1时，输出汉字“春季”
				break;
			case 2:
				System.out.println("春季"); //当a为2时，输出汉字“春季”
				break;
			case 3:
				System.out.println("春季"); //当a为3时，输出汉字“春季”
				break;
			case 4 :
				System.out.println("夏季"); //当a为4时，输出汉字“夏季”
				break;
			case 5:
				System.out.println("夏季"); //当a为5时，输出汉字“夏季”
				break;
			case 6:
				System.out.println("夏季"); //当a为6时，输出汉字“夏季”
				break;
			case 7 :
				System.out.println("秋季"); //当a为7时，输出汉字“秋季”
				break;
			case 8:
				System.out.println("秋季"); //当a为8时，输出汉字“秋季”
				break;
			case 9:
				System.out.println("秋季"); //当a为9时，输出汉字“秋季”
				break;
			case 10 :
				System.out.println("冬季"); //当a为10时，输出汉字“冬季”
				break;
			case 11:
				System.out.println("冬季"); //当a为11时，输出汉字“冬季”
				break;
			case 12:
				System.out.println("冬季"); //当a为12时，输出汉字“冬季”
				break;
		}
	}
	
	
	/**
	 *
	 * 输入一个数字ａ
	 */
	public static void jijie3(int a){
		if(a >=1 && a<=3){
			System.out.println("春季");  //如果 a>=1并且 a<=3  则输出汉字“春季”
		}else if(a >=4 && a<=6){
			System.out.println("夏季");  //如果 a>=4并且 a<=6  则输出汉字“夏季”
		}else if(a>=7&& a<=9){
			System.out.println("秋季");  //如果 a>=7并且 a<=9  则输出汉字“秋季”
		}else if(a>=10&& a<=12){
			System.out.println("冬季");  //如果 a>=10并且 a<=12  则输出汉字“冬季”
		}
	}
	
	
	/**
	 *
	 * 输入一个数字ａ
	 */
	public static void jijie4(int a){
	        //如果 a>=1并且 a<=3  则输出汉字“春季”
		if(a >=1 && a<=3) System.out.println("春季"); 
		//如果 a>=4并且 a<=6  则输出汉字“夏季”
		else if(a >=4 && a<=6) System.out.println("夏季");
		//如果 a>=7并且 a<=9  则输出汉字“秋季”
		else if(a>=7&& a<=9) System.out.println("秋季");  
		//如果 a>=10并且 a<=12  则输出汉字“冬季”
		else if(a>=10&& a<=12) System.out.println("冬季");  
	
	}
	
	
	
	public static void quyu(){
	    int a = 7;
	    int b = a%2;
	    System.out.println(b);
	}
	
	/**
	 *
	 * 输入一个数字ａ
	 */
	public static void quyu2(int a){
	    //如果a%2结果为0  则输出“它是偶数”
	    if (a%2 == 0)  System.out.println("它是偶数");   
	    //否则 输出“它不是偶数”
	    else System.out.println("它不是偶数");
	}
	
	/**
	 *
	 * 输入一个数字ａ,代表年份
	 */
	public static void runnian(int a){
	    //如果a能被4整除并且不能被100整除  则输出“这一年是有366天”
	    if (a%4 == 0 && a%100 != 0)  System.out.println("这一年有366天");  
	    //否则,如果a能被400整除  则输出“这一年有366天”
	    else if (a%400 == 0)  System.out.println("这一年有366天"); 
	    //否则，输出“这一年有365天”
	    else System.out.println("这一年有365天");
	}
}
