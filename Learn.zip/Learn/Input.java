import java.util.Scanner; //声明引入Scanner工具类

public class Input   //我们自己定义的程序类
{    
    public static void input()  //我们自己定义的程序方法
    {
        //开始使用Scanner工具类
        Scanner sc = new Scanner(System.in);     
        //使用while循环判断是否有新的输入
        while (sc.hasNextLine()) {
            //获取从键盘输入的数据
            String input = sc.nextLine();
            //在电脑中输出从键盘输入的数据
            System.out.println(input);
        }
    }   
}
