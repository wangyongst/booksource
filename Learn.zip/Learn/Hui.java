
public class Hui
{
    /**
     * 让电脑验证哥德巴赫猜想
     * 
     * 从键盘输入一个大于2的偶数a；
     *      
     */
    public static void gdbhcx(int a)
	{
		/**
		 * for循环定义整数型变量t，并初始化它的值为2；
		 * for循环布尔表达式条件为t < a/2；
		 * for循环变量更新为t++；
		 */
		for(int t = 2; t < a/2 ; t ++){
			/**
			 * 循环判断t是否为质数
			 */
			for(int i = 2 ; i < t ; i ++){
				if(t % i == 0){  //循环判断a% i== 0是否为真
					System.out.println(t+"不是质数");    //为真，则t不是质数
					break; //循环提前结束
				}
				//循环没有提前结束，也就是当循环执行完i=t-1时的判断后，则t是质数
				if(i == t - 1){
					System.out.println(t+"是质数");
					/**
					 * 循环判断a-t是否为质数
					 */
					for(int j = 2 ; j < (a-t) ; j ++){
						if((a - t) % j == 0){  //循环判断(a-t) % j== 0是否为真
							System.out.println(t+"不是质数");    //为真，则a不是质数
							break; //循环提前结束
						}
						//循环没有提前结束，也就是当循环执行完j=(a-t) -1时的判断后，则a是质数
						if(j == (a - t)  - 1){
							System.out.println(a - t+"是质数");
							System.out.println("找到两个质数分别是"+ t +"和"+ (a - t) + "的和是" + a);
							return;
						}
					}
				}
			}
		}
	}
	
	/**
	 * 判断从键盘输入的一个数是几位数
	 */
	public static void weishu(int a)
	{
	    int b = a;
	    int c = 0;
	    if(b == 0 )
	    {
	        System.out.println("0是1位数");
	    }else{	    
	        while(b > 0){
	            b = b/10;
	            c ++;
	        }
	        System.out.println(a + "是" + c + "位数");
	   }
	}
	
	
	/**
	 * Java中内置的数学方法
	 */
	public static void math()
	{
	    /**
	     * 得到两个数中的最大值
	     */
	    System.out.println(Math.max(1,3)); //3
	    /**
	     * 得到两个数中的最小值
	     */
	    System.out.println(Math.min(1,3)); //1
	    /**
	     * 计算a的b次幂，也就是a的b次方，注意得到的结果是double型
	     */
	    System.out.println(Math.pow(5,4));	//625.0
	    /** 
             * 得到四舍五入后的整数
             */  
            System.out.println(Math.round(10.3));   //10 
            /**
             * 计算一个数的平方根，，注意得到的结果是double型
             */
	    System.out.println(Math.sqrt(16));   //4.0 
	    /** 
             * 得到一个数的绝对值 
             */
	    System.out.println(Math.abs(-10.4));    //10.4 
	    /** 
             * random 取得一个大于或者等于0.0小于不等于1.0的随机数 
             */  
            System.out.println(Math.random());  //小于1大于0的double类型的数
	}
	
    /**
     * 找到所有8位数以内的全部自幂数
     */
    public static void zimi()
    {
        /**
         * for循环定义整数型变量i，并初始化它的值为0；
	 * for循环布尔表达式条件为i < 9999999；
	 * for循环变量更新为i++；
	 * for循环依次数从0到9999999的所有数
         */
        for(int i = 0 ; i <=9999999 ; i ++){
            //变量b用来做除10计算
            int b = i;
            //变量d计算数字i的位数
            int d = 0;
            //0是自幂数，但不适用于后面的计算方法，单独处理
            if(b == 0 )
	    {
	        System.out.println("找到自幂数0");
	    }else{
	        //通过while循环计算i的位数
                while(b > 0){
                    b = b/10;
                    d ++;
                }
                //变量c用来做再一次除10循环
                int c = i;
                //变量e保存自幂运算的结果
                double e = 0;
                //通过while循环计算i的自幂运算结果
                while(c > 0)
                {
                    //使用Java内置方法计算自幂结果
                    e= e + Math.pow(c%10,d);
                    c = c/10;
                }
                //自幂运算的结果和i相等，则i是自幂数
                if(e == i)
                {
                    System.out.println("找到自幂数"+ i );
                }
            }
        }
        
        int a = 1;
        int b = 3;
        int c = 0;
        if(a > b )
        {
            c = a;
        }else{
            c = b;        
        }    
    }
}
