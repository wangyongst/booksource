/**
 * 计算学生平均成绩程序
 * 能自动接收键盘输入的学生成绩，并自动累计学所有已输入的学生成绩总和
 * 能自动计数已经输入的学生成绩个数，并通过学生成绩总和和成绩个数计算平均成绩
 * 具有退出程序功能
 */
import java.util.Scanner;
public class ChengJi
{
    public static void chengJi() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入学生的成绩：");
        //定义并初始化变量记录成绩总和
        int all = 0;
        //定义并初始化变量记录成绩个数
        int count = 0;
        while (sc.hasNext()) 
        {
            //通过Scanner工具类的nextInt（）方法，使程序只接收数字型的输入
            int a = sc.nextInt();
            //只计算输入的学生成绩大于等于0分的情况
            if (a >= 0)
            {
                //有新的学生成绩输入时，成绩个数自增
                count++;
                //输出输入了第几个学生成绩和输入的成绩数
                System.out.println("你已经输入的第" + count + "个学生的成绩是" + a);
                //记录成绩总和
                all = all + a;
                //用成绩总和除以成绩个数计算平均分
                double c = all / count;
                //输出输入了多个个学生的成绩和计算得出的平均成绩
                System.out.println("你输入的" + count + "个学生的平均成绩是" + c);
            }
            //输入的学生成绩不是大于等于0分的情况时，退出程序
            else
            {
              return;
            }
            System.out.print("请输入学生的成绩：");
        }
    }
}
