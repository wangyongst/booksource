public class NiHao{
    public static void print()
    {
        System.out.println("你好");
    }
    
    public static void print2()
    {
        System.out.println(357+458);
    }
}
