public class Array
{
   public static void arrays(){       
       int[] a = {1,2,3,4,5,6,7,8,9,10};
       System.out.println(a[0]);
       System.out.println(a[1]);
       System.out.println(a[2]);
       System.out.println(a[3]);
       System.out.println(a[4]);
       System.out.println(a[5]);
       System.out.println(a[6]);
       System.out.println(a[7]);
       System.out.println(a[8]);
       System.out.println(a[9]);
   } 
   
   public static void arrays2(){       
       int[] a = {1,2,3,4,5,6,7,8,9,10};
       for(int i = 0 ; i < 10 ; i++){
           System.out.println(a[i]);
       }   
   }
   
   
   public static void arrays3(){       
       int[] a = {1,2,3,4,5,6,7,8,9,10};
       for(int n : a){
           System.out.println(n);
       }   
   }
   
   
   public static void paixu() {
	/**
         * 定义并初始化整数型数组变量a
         * 并把3，2，4，1这4个数字存储在变量a中
         */
	int[] a = {3, 2, 4, 1};
        /**
         * 冒泡排序的for循环实现方法
         * 变量i代表循环轮数
         * 用a[j]访问要比较的数据，用a[j+1]访问a[j]右边的数据
	 */
	for (int i = 0; i < 4; i++) {
	        /**
	         * j < 4 -1 - i代表要比较到哪一位数据为止
	         */
		for (int j = 0; j < 4-1-i; j++) {
			/**
			* 如果当前数据比右边位置的数据大，就交换两个数据的位置
			*/
			if (a[j] > a[j+1]) {
				int x = a[j+1];
				a[j+1] = a[j];
				a[j] = x;
			}
		}
	}
        /**
        * 用for循环的数组遍历语法，让电脑依次输出数组中的值
        */
	for(int n : a){
		System.out.println(n);
	}
   }

}