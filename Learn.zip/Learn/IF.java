public class IF
{
    public static void print()
    {
        boolean a = (1 >0 );
        System.out.println(a);
    }
    
    public static void print2()
    {
        int a = 1;
        int b = 0;
        boolean c = (a > b);  //表达式成立，变量c的值是true
        boolean d = (a < b);  //表达式不成立，变量d的值是false
        boolean e = (a == b); //表达式不成立，变量e的值是false
        boolean f = (a >= b);  //表达式成立，变量f的值是true
        boolean g = (a <= b);  //表达式不成立，变量g的值是false
        boolean h = (a != b);  //表达式成立，变量h的值是true
    }
    
   public static void bool()
    {
        int a = 1;
        int b = 0;
        int c = 1;
        int d = 0;
        boolean e = (a > b && c < d); //表达式不成立，变量e的值是false
        boolean f = (a > b || c < d);  //表达式成立，变量f的值是true
        boolean g = !(a < b);  //变量g的值是false
    }
    
    public static void bool2()
    {
        int a = 1;
        int b = 0;
        
        if(a > b){
             System.out.println(" a 大于 b");
        }
        
        if(a < b){
             System.out.println(" a 小于 b");
        }
    }
    
    public static void bool3(int a ,int b)
    {
        
        if(a > b){
             System.out.println(" a 大于 b");
        }
        
        if(a < b){
             System.out.println(" a 小于 b");
        }
    }
    
    
    public static void equals(int b)
    {
        int a = 38;  //让电脑存储一个变量，这里我设定它的值38
        if(a > b){   //如果变量a的数值比键盘输入的参数b的数值大 
             System.out.println("我比"+b+"大");
        }
        
        if(a < b){  //如果变量a的数值比键盘输入的参数b的数值小 
             System.out.println("我比"+b+"小");
        }
        
        if(a == b){  //如果变量a的数值和键盘输入的参数b的数值相等
             System.out.println("猜对了");
        }
    }
    
    public static void score(int a)
    {
        if(a < 60){   //键盘输入的参数a小60 
             System.out.println("不及格");
        }        
        else{  //其它条件
             System.out.println("及格");
        }
    }
    
    
    public static void score2(int a)
    {
        if(a < 60){   //小于60分
             System.out.println("不及格");
        }        
        else{  //其它条件
             if(a >= 80){  //大于等于80分
                 System.out.println("优秀");
             }
             else{ //其它条件
                 System.out.println("及格");
            }                 
        }
    }
    
    /**
     * 从键盘输入三个数字，a、b、c
     */
    public static void bijiao(int a,int b,int c){
        int d = 0; //定义一个变量d,用来存放最大的数
        /**
         * 比较a和b的大小
         */
        if(a >=b){ 
            d = a;  //如果，a>=b，把a放进变量d
        }else{
            d = b;  //否则，把b放进变量d
        }
        /**
         * 比较c和d的大小
         */
        if(c >= d){
            System.out.println(c);  //如果，c>=d，输出c为最大数
        }else{
            System.out.println(d);//否则，输出d为最大数
        }
    }
}
