/**
 * 收银柜台收款程序
 * 能自动接收键盘输入的商品价格，并自动累加商品总价
 * 具有归零和退出程序功能
 */
import java.util.Scanner;
public class ShouYin
{
    public static void shouyin() {
        Scanner sc = new Scanner(System.in);
        //记录商品总价
        int count = 0;
        while (sc.hasNext()) {
            //通过Scanner工具类的nextInt（）方法，使程序只接收数字型的输入
            int in = sc.nextInt();
            //从键盘输入数字0，则商品总价自动归零
            if (in == 0) {
                count = 0;
                System.out.println("价格合计归零");
            } else if (in == -1) {
                //从键盘输入数字-1，则退出程序
                return;
            } else {
                System.out.println("输入的商品价格为：" + in);
                //商品总价累计
                count = count + in;
                System.out.println("当前价格合计为：" + count + "元");
            }
            System.out.print("请输入商品价格：");
        }
    }
}
