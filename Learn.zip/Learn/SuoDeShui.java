/**
 * 计算个人所得税程序
 * 能自动接收键盘输入的税前工资总额，并自动累加商品总价
 * 根据个人所得税征收标准及税率自动计算应缴纳的个人所得税额
 * 具有退出程序功能
 */
import java.util.Scanner;
public class SuoDeShui
{
     public static void suoDeShui() {
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入税前工资总额（单位：元）：");
        while (sc.hasNext()) {
            //通过Scanner工具类的nextInt（）方法，使程序只接收数字型的输入
            int a = sc.nextInt();
            //从键盘输入数字0，则退出程序
            if (a == 0) {
                return;
            }
            //按个人所得税起征点5000元，计算应纳税额部分
            int b = a - 5000;
            if (b <= 0) {
                //应纳税额小于等于0时，免征人个所得税
                System.out.println("你的税前工资总额未达到起征点，免征人个所得税！");
            } else if (b > 0 && b <= 3000) {
                //应纳税额小于等于3000元时，税率为3%
                double c = b * 0.03;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 3000 && b <= 12000) {
                //应纳税额小于等于12000元时，税率为10%
                double c = b * 0.1;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 12000 && b <= 25000) {
                //应纳税额小于等于25000元时，税率为20%
                double c = b * 0.2;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 25000 && b <= 35000) {
                //应纳税额小于等于35000元时，税率为25%
                double c = b * 0.25;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 35000 && b <= 55000) {
                //应纳税额小于等于55000元时，税率为30%
                double c = b * 0.3;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 55000 && b <= 80000) {
                //应纳税额小于等于80000元时，税率为35%
                double c = b * 0.35;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            } else if (b > 80000) {
                //应纳税额大于80000元时，税率为45%
                double c = b * 0.45;
                System.out.println("你的税前工资为：" + a + "元，应纳个人所得税为：" + c + "元");
            }
            System.out.print("请输入税前工资总额（单位：元）：");
        }
    }
}
