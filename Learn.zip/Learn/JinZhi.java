public class JinZhi
{
   /**
     * 把任意从键盘输入的数字转化成二进制输出
     *      
     */
    public static void erjinzhi(int a)
    {            
        System.out.println(Integer.toBinaryString(a));
        System.out.println(Integer.toOctalString(a));
        System.out.println(Integer.toHexString(a));
    }
    
    
    /**
     * 二维数组存储ASCII码表并输出显示
     *      
     */
    public static void ascii()
    {            
       char[][] a = {
        {32,48,64,80,96,112},
        {33,49,65,81,97,113},
        {34,50,66,82,98,114},
        {35,51,67,83,99,115},
        {36,52,68,84,100,116},
        {37,53,69,85,101,117},
        {38,54,70,86,102,118},
        {39,55,71,87,103,119},
        {40,56,72,88,104,120},
        {41,57,73,89,105,121},
        {42,58,74,90,106,122},
        {43,59,75,91,107,123},
        {44,60,76,92,108,124},
        {45,61,77,93,109,125},
        {46,62,78,94,110,126},
        {47,63,79,95,111,127}
        };
        
        for(char[] n : a)
        {
            for(char t : n)
            {
                System.out.print(t + "\t");
            }
            System.out.println();
        }        
    }
    
    /**
     * 二维数组存储ASCII码表
     *      
     */
    public static void ascii2()
    {            
        int[][] a  = new int[16][6];
        int i = 32 ;      
        for(int j = 0 ; j < 6 ; j ++)
        {
           for(int k  = 0 ; k < 16 ; k ++)
           {
             a[k][j] = i ++;
           }            
        }
        
        for(int[] n : a)
        {
            for(int t : n)
            {
                System.out.print(t);
                System.out.print(",");
            }
            System.out.println();
        }
    }
    
    
    /**
     * 不同进制中数字的表示
     *      
     */
    public static void jiafa()
    {      
        int a = 17;
        int b = 017;
        int c = 0x17;
        System.out.println(a+b+c);
    }
    
    
    /**
     * 输出从32到127所有十进制数代表的字符
     *      
     */
    public static void zifu()
    {      
        for(char i = 32 ; i < 127 ; i ++){
            System.out.print(i);
        }    
    }
    
    /**
     * 输出“我是中国人”在Unicode码中的十进制数值和二进制数
     *      
     */
    public static void hanzi()
    {   
        char[] c = {'我','是','中','国','人'};      
        for(int i : c){
            System.out.println(i);
            System.out.println(Integer.toBinaryString(i));
            System.out.println(Integer.toOctalString(i));
            System.out.println(Integer.toHexString(i));
        }    
    }    
    
    
    /**
     * 输出“汪泳”两个字在电脑中的相加结果
     *      
     */
    public static void mingzi()
    {   
        char a = '汪';
        char b = '泳';        
        System.out.println(a+b);
             
    }
}

